#ifndef UTIL_H
#define UTIL_H

void errif(bool, const char*);

#endif