/**
 * @file Log.h
 * @author 冯岳松 (yuesong-feng@foxmail.com)
 * @brief 
 * @version 0.1
 * @date 2022-02-07
 * 
 * @copyright Copyright (冯岳松) 2022
 * 
 */
#pragma once
class Log
{
private:
    /* data */
public:
    Log(/* args */);
    ~Log();
};

Log::Log(/* args */)
{
}

Log::~Log()
{
}
            